/*
 * Copyright (C) 2015-2017 Alibaba Group Holding Limited
 */

// Auto-generated build information. see scripts/echo_git_version.sh
#ifndef ALINK_AGENT_GIT_VERSION
#define ALINK_AGENT_GIT_VERSION "smarthome-bd18d6d"
#define ALINK_AGENT_BUILD_DATE "Thu Feb  9 01:44:23 Local time zone must be set--see zic manual page 2017"
#define ALINK_AGENT_BUILD_TIME "xxx"
#endif
