#ifndef __LIGHT_H__
#define __LIGHT_H__


int light_init(void);
int light_exit(void);

#endif
